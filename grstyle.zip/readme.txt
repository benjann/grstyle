Recommended installation procedure:

 Type -ssc install grstyle, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download grstyle.zip.

 2. Unzip grstyle.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install grstyle, replace-.

30jan2019, Ben Jann
